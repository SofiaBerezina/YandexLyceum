import pygame
import os
import sys


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image

def move(direction):
    if direction == 'up':
        creature.rect = creature.rect.move(0, - 10)
    elif direction == 'down':
        creature.rect = creature.rect.move(0, 10)
    elif direction == 'right':
        creature.rect = creature.rect.move(10, 0)
    elif direction == 'left':
        creature.rect = creature.rect.move(- 10, 0)


if __name__ == '__main__':
    pygame.init()
    size = width, height = 300, 300
    screen = pygame.display.set_mode(size)
    running = True
    screen.fill((255, 255, 255))
    pygame.display.set_caption('Герой двигается!')
    all_sprites = pygame.sprite.Group()
    creature_image = load_image('creature.png')
    creature = pygame.sprite.Sprite(all_sprites)
    creature.image = creature_image
    creature.rect = creature.image.get_rect()
    creature.rect.x = 10
    creature.rect.y = 10
    all_sprites.draw(screen)
    while running:
        screen.fill((255, 255, 255))
        all_sprites.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    move('up')
                if event.key == pygame.K_DOWN:
                    move('down')
                if event.key == pygame.K_RIGHT:
                    move('right')
                if event.key == pygame.K_LEFT:
                    move('left')
        pygame.display.flip()
    pygame.quit()
